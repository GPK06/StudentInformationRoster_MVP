/* Important class that takes care of the routing. */
/* When a method is called, this class takes care of switching URLs and manipulating the values.*/
/* This class is also linked to the Back End and a client (PostMan Agent) that does the work all together. */

import axios from 'axios';

// Final variable that has the Back-End URL.
const STUDENT_API_BASE_URL = "http://localhost:8080/api/v1/students";

class StudentService {

    // Call the PostMan get method when called.
    getStudents() {
        return axios.get(STUDENT_API_BASE_URL);
    }

    // Call the PostMan post method when called.
    createStudent(student) {
        return axios.post(STUDENT_API_BASE_URL, student);
    }

    // Call the PostMan get method when called.
    getStudentById(studentId) {
        return axios.get(STUDENT_API_BASE_URL + '/' + studentId)
    }

    // Call the PostMan put method when called.
    updateStudent(student, studentId) {
        return axios.put(STUDENT_API_BASE_URL + '/' + studentId, student)
    }

    // Call the PostMan delete method when called.
    deleteStudent(studentId) {
        return axios.delete(STUDENT_API_BASE_URL + '/' + studentId)
        // The below code changes this function to an async one to properly model the backend requests
        .then(
            function(response) {
                console.log(response)
            })
            .catch(function (error) {
                console.log(error)
            })
            .then(function() {

            });
    }
}

export default new StudentService()