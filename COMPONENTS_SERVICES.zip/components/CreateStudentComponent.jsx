/* Add Student Class. This class creates a student object with the given inputs. */
import React, { Component } from 'react'
import StudentService from '../services/StudentService';

class CreateStudentComponent extends Component {
    constructor(props) {
        super(props)

        // Creates a 'set' with the following fields
        this.state = {
            id: this.props.match.params.id,
            firstName: '',
            lastName: '',
            emailId: ''
        }
        
        // Binds (update) the fields
        this.changeFirstName = this.changeFirstName.bind(this);
        this.changeLastName = this.changeLastName.bind(this);
        this.saveStudent = this.saveStudent.bind(this);
    }

    // Method that checks if the components of the set has rendered properly.
    componentDidMount() {

        // Condition goes to that URL when entered (or called through buttons).
        if (this.state.id === '_add') {
            return

        // Constantly renders and sets the 'state' until page is loaded.
        } else {

            // Gets the student ID and changes the field values (from null) to the new value.
            StudentService.getStudentById(this.state.id).then( (res) => {
                let student = res.data;
                this.setState
                ({firstName: student.firstName,
                    lastName: student.lastName,
                    emailId : student.emailId
                });
            });
        }        
    }

    // The save method that finalizes the variables in the set.
    saveStudent = (e) => {
        e.preventDefault(); // Stops the default action of the element from happening
        let student = {firstName: this.state.firstName, lastName: this.state.lastName, emailId: this.state.emailId};
        console.log('student => ' + JSON.stringify(student)); // Prints an array of student object to the console.
        
        // Condition that pushes the page back to Students List page from the URL when saved.
        if (this.state.id === '_add') {
            StudentService.createStudent(student).then(res => {
                this.props.history.push('/students');
            });

        // Else, pushes the page back to Students List page after updating.
        } else {
            StudentService.updateStudent(student, this.state.id).then(res => {
                this.props.history.push('/students');
            });
        }
    }
    
    // Method that changes the first name of the student
    changeFirstName = (event) => {
        this.setState({firstName: event.target.value});
    }

    // Method that changes the last name of the student
    changeLastName = (event) => {
        this.setState({lastName: event.target.value});
    }

    // Method that changes the email address of the student
    changeEmail = (event) => {
        this.setState({emailId: event.target.value});
    }

    // Cancel button that loads the Students List page when clicked.
    cancel() {
        this.props.history.push('/students');
    }

    // Method that checks the URL to load the title of the page.
    getTitle() {

        // If the URL is 'add', then Add Student will be the title.
        if (this.state.id === '_add') {
            return <h3 className="text-center">Add Student</h3>
        
        // If the URL is 'update', then Edit Student will be the title.
        } else {
            return <h3 className="text-center">Edit Student</h3>
        }
    }

    // Method that loads (or renders) the content
    render() {
        return (
            <div>
                <br></br>

                    {/* The DIV that loads the title. */}
                    <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                {
                                    this.getTitle()
                                }

                                {/* The DIV that loads the form. */}
                                <div className = "card-body">
                                    <form>

                                        {/* The DIV that gets the input for first name and calls the change method. */}
                                        <div className = "form-group">
                                            <label> First Name: </label>
                                            <input placeholder="First Name" name="firstName" className="form-control" 
                                                value={this.state.firstName} onChange={this.changeFirstName}/>
                                        </div>

                                        {/* The DIV that gets the input for last name and calls the change method. */}
                                        <div className = "form-group">
                                            <label> Last Name: </label>
                                            <input placeholder="Last Name" name="lastName" className="form-control" 
                                                value={this.state.lastName} onChange={this.changeLastName}/>
                                        </div>

                                        {/* The DIV that gets the input for email address and calls the change method. */}
                                        <div className = "form-group">
                                            <label> Email Id: </label>
                                            <input placeholder="Email Address" name="emailId" className="form-control" 
                                                value={this.state.emailId} onChange={this.changeEmail}/>
                                        </div>

                                        {/* Buttons that call their respective funtions when clicked. */}
                                        <button className="btn btn-success" onClick={this.saveStudent}> Save </button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}> Cancel </button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
        )
    }
}

export default CreateStudentComponent
