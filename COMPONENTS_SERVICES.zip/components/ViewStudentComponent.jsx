/* View Student Class. This class shows a student object. */
import React, { Component } from 'react'
import StudentService from '../services/StudentService'

class ViewStudentComponent extends Component {
    constructor(props) {
        super(props)

        // Creates a 'set' with a student ID, and a student array.
        this.state = {
            id: this.props.match.params.id,
            student: []
        }
    }

    // Method that checks if the components of the set has rendered properly.
    componentDidMount() {

        // Gets student ID and sets the arrays value with the values of the student object
        StudentService.getStudentById(this.state.id).then(res => {
            this.setState({student: res.data});
        })
    }

    // Method that loads (or renders) the content
    render() {
        return (
            <div>
                <br></br>

                {/* The DIV that loads the text box. */}
                <div className = "card col-md-6 offset-md-3">
                    <h3 className = "text-center"> View Student Details </h3>
                    <div className = "card-body">

                        {/* The DIV that shows the first name of the student */}
                        <div className = "row">
                            <label> Student First Name: </label>
                            <div> {this.state.student.firstName} </div>
                        </div>

                        {/* The DIV that shows the last name of the student */}
                        <div className = "row">
                            <label> Student Last Name: </label>
                            <div> {this.state.student.lastName} </div>
                        </div>

                        {/* The DIV that shows the email address of the student */}
                        <div className = "row">
                            <label> Student Email ID: </label>
                            <div> {this.state.student.emailId} </div>
                        </div>
                    </div>

                </div>
            </div>
        )
    }
}

export default ViewStudentComponent
