/* Important class that links the ADD, UPDATE, DELETE and VIEW Components. Takes care of button clicks. */
import React, { Component } from 'react'
import StudentService from '../services/StudentService'

class ListStudentComponent extends Component {
    constructor(props) {
        super(props)

        // Create a set with a student array.
        this.state = {
            students: []
        }

        // Binds (update) the methods
        this.addStudent = this.addStudent.bind(this);
        this.editStudent = this.editStudent.bind(this);
        this.deleteStudent = this.deleteStudent.bind(this);
    }

    // Method that calls the delete function (backend) using the inputted id.
    deleteStudent(id) {
        StudentService.deleteStudent(id).then(res => {
            this.setState({students: this.state.students.filter(student => student.id !== id)});
        }).catch(error => console.log(error)); // Throws whatever error to the console when encountered.
    }

    // Method that loads the URL using the ID of the student to show the content
    viewStudent(id){
        this.props.history.push(`/view-student/${id}`);
    }

    // Method that loads the URL using the ID of the student to load the form
    editStudent(id){
        this.props.history.push(`/add-student/${id}`);
    }

    // Async function: tries to sync with the server as much as possible (throws error if it doesn't)
    // Method that checks if the components of the set has rendered properly.
    async componentDidMount(){

        // Wait until it is synced with the server before adding the values to the array.
        await StudentService.getStudents().then((res) => {
            this.setState({students: res.data});
        });
    }

    // Method that loads the URL to load the add form.
    addStudent(){
        this.props.history.push('/add-student/_add');
    }

    // Method that loads (or renders) the content
    render() {
        return (
            <div>
                {/* Title of the Page */}
                 <h2 className="text-center">Students List</h2>

                {/* Loads the add button and calls the addStudent function when clicked. */}
                 <div className = "row">
                    <button className="btn btn-primary" onClick={this.addStudent}> Add Student </button>
                 </div>

                 <br></br>

                {/* Creates a table with 4 separate columns */}
                 <div className = "row">
                        <table className = "table table-striped table-bordered">

                            {/* Header of the columns */}
                            <thead>
                                <tr>
                                    <th> Student First Name</th> {/* First name column */}
                                    <th> Student Last Name</th> {/* Last name column */}
                                    <th> Student Email Id</th> {/* Email column */}
                                    <th> Actions</th> {/* Actions (different buttons) column */}
                                </tr>
                            </thead>

                            {/* Body of the page and the table */}
                            <tbody>
                                {/* Using the array, it fetches the information and stores into a map. */}
                                {
                                    this.state.students.map(
                                        student => 
                                        <tr key = {student.id}> {/* Get Student ID */}
                                             <td> {student.firstName} </td> {/* Get Student First Name */}
                                             <td> {student.lastName}</td> {/* Get Student Last Name */}
                                             <td> {student.emailId}</td> {/* Get Student Email */}
                                             <td>

                                                {/* Buttons that call their respective funtions when clicked. */}
                                                 <button onClick={ () => this.editStudent(student.id)} className="btn btn-success"> Edit </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.deleteStudent(student.id)} className="btn btn-danger"> Delete </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.viewStudent(student.id)} className="btn btn-info"> View </button>
                                             </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>

                 </div>

            </div>
        )
    }
}

export default ListStudentComponent
