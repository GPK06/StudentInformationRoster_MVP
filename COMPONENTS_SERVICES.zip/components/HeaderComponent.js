/* The Header Class that loads the header of the page. */
// Also want to state that the class structure is created using React Snippets
// (The reason every class looks the same. And also why there are empty states.)
import React, { Component } from 'react'

class HeaderComponent extends Component {
    constructor(props) {
        super(props)

        // Empty state.
        this.state = {
                 
        }
    }

    // Method that loads (or renders) the content
    render() {
        return (
            <div>
                <header>
                    {/* Header content, Title of the Project. */}
                    <nav className="navbar navbar-expand-md navbar-dark bg-dark">
                        <div className="navbar-brand">Student Roster Manager</div>
                    </nav>
                </header>
            </div>
        )
    }
}

export default HeaderComponent
