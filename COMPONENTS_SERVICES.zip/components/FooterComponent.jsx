/* The Footer Class that loads the footer of the page. */
// Also want to state that the class structure is created using React Snippets
// (The reason every class looks the same. And also why there are empty states.)
import React, { Component } from 'react'

class FooterComponent extends Component {
    constructor(props) {
        super(props)

        // Empty state.
        this.state = {
                 
        }
    }

    // Method that loads (or renders) the content
    render() {
        return (
            <div>
                {/* Footer content, copyrights. */}
                <footer className = "footer">
                    <span>All Rights Reserved 2022, Gopinath Prem Kumar</span>
                </footer>
            </div>
        )
    }
}

export default FooterComponent
