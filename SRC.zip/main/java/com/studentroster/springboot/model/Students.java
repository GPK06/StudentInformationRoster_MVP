package com.studentroster.springboot.model;

import javax.persistence.*;

@Entity
@Table(name = "Students")
public class Students {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long serialNum;
	
	@Column(name = "Age")
	private int age;
	
	@Column(name = "First Name")
	private String firstName;
	
	@Column(name = "Last Name")
	private String lastName;
	
	@Column(name = "Gender")
	private String gender;
	
	public Students() {
		
	}
	
	public Students(int age, String firstName, String lastName, String gender) {
		super();
		this.age = age;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	
	public long getSerialNum() {
		return serialNum;
	}
	
	public void setSerialNum(long serialNum) {
		this.serialNum = serialNum;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getGender() {
		return gender;
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}	

}
