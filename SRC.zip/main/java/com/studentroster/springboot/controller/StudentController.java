package com.studentroster.springboot.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.studentroster.springboot.model.Students;
import com.studentroster.springboot.repository.StudentRepository;

@RestController
@RequestMapping("/api/v1/")
public class StudentController {
	
	@Autowired
	private StudentRepository stud_rep;
	
	// Get All Students
	@GetMapping("/students")
	public List<Students> getAllStudents() {
		return stud_rep.findAll();
	}

}
